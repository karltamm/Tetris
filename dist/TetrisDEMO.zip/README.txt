NB! This version is only meant for demonstration purposes. 

Compared to the regular version, a player doesn't have to
"earn" power-ups by clearing rows. In other words, a player
can use the power-ups all the time. Furthermore, all unlockable
themes are already unlocked.